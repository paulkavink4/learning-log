export interface ApiResponse<T>{
    success:boolean
    message:string
    data?:T
}

//Data is optional here and have generic value
//this api response interface will be resuable with document and users

