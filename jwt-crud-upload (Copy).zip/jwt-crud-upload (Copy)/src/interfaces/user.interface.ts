export type Role = "admin" | "employee" | "manager";

export interface User {
  id: number;
  username: string;
  password: string;
  role: Role;
}
