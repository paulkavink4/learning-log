import { Worker } from "worker_threads";
import path from "path";
import multer from "multer";
import { Request, Response } from "express";
import { registerUser, loginUser } from "../services/auth.service";
import { documents } from "../data/documents";


export const register = async (req: any, res: any) => {
  const user = await registerUser(
    req.body.username,
    req.body.password,
    req.body.role,
  );

  res.json(user);
};

export const login = async (req: any, res: any) => {
  const token = await loginUser(req.body.username, req.body.password);

  if (!token) {
    return res.status(404).json({
      message: "Invalid Credentials",
    });
  }
  res.json({ token });
};


//Upload Document

export const upload = multer({
  dest: "uploads/", //dest means destination folder
});

// export const uploadCsv = (req: any, res: any) => {
//   res.json({
//     success: true,
//     file: req.file,
//   });
// };

export const uploadCsv = (req: Request, res: Response) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: "No file uploaded" });
  }

  const worker = new Worker(
    path.resolve(__dirname, "../workers/csvWorker.ts"), // .js because compiled
    {
      workerData: { filePath: req.file.path },
    }
  );

  worker.on("message", (result) => {
    if (!result.success) {
      return res.status(500).json({ success: false, message: result.error });
    }
    res.status(200).json({
      success: true,
      rowCount: result.rows.length,
      data: result.rows,
    });
  });
 
  worker.on("error", (err:Error) => {
    res.status(500).json({ success: false, message: err.message });
  });
};
