import { Request, Response } from "express";

import {
  getDocuments as getDocumentsService,
  createDocument as createDocumentService,
  updateDocument as updateDocumentService,
  deleteDocument as deleteDocumentService
}
from "../services/document.service";

//GET
export const getDocuments = (
  req: Request,
  res: Response
) => {

  const documents =
    getDocumentsService();

  res.status(200).json({
    success: true,
    data: documents
  });
};

//CREATE

export const createDocument = (
  req: Request,
  res: Response
) => {

  const { title } = req.body;

  const document =
    createDocumentService(title);

  res.status(201).json({
    success: true,
    data: document
  });
};

//UPDATE

export const updateDocument=(req:Request,res:Response)=>{
    const id= Number(req.params.id) // string -> number type casting
    const {title} =req.body

    const updateDocument=updateDocumentService(id,title)

    if(!updateDocument){
        return res.status(404).json({
            status:false,
            message:"Not Found"
        })
    }

    res.status(200).json({
        status:true,
        data:updateDocument
    })
}

//DELETE
export const deleteDocument = (
  req: Request,
  res: Response
) => {

  const id = Number(req.params.id);

  const deleted =
    deleteDocumentService(id);

  if (!deleted) {
    return res.status(404).json({
      success: false,
      message: "Document not found"
    });
  }

  res.status(200).json({
    success: true,
    message: "Deleted successfully"
  });
};