import { Document } from "../interfaces/document.interface";

export const documents: Document[] = [];
