import { documents } from "../data/documents";
//CRUD
//Create

export const createDocument = (title: string) => {
  const document = {
    id: documents.length + 1,
    title: title,
  };
  documents.push(document);
  return document;
};

//Read
export const getDocuments = () => documents;

//Update
export const updateDocument = (id: number, title: string) => {
  const doc = documents.find((d) => d.id == id);

  if (doc) {
    doc.title = title;
  }
  return doc;
};

//Delete

export const deleteDocument = (id: number) => {
  const index = documents.findIndex((d) => d.id == id);
  if (index != -1) {
    documents.splice(index, 1);
    return documents;
  }
};
