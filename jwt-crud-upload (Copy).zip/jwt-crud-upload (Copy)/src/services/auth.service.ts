import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { users } from "../data/users";
import { Role } from "../interfaces/user.interface";

const SECRET = "secret123";

//for role , the type is Role which our own created type/alias in interface
export const registerUser = async (
  username: string,
  password: string,
  role: Role,
) => {
  const hashedPassword = await bcrypt.hash(password, 10);
  //Here 10 indicates layers of secruity , eg: 1244--> efvgj$%^43F*%*
  const user = {
    id: users.length + 1,
    username,
    password: hashedPassword,
    role,
  };

  users.push(user);
  return user;
};

export const loginUser = async (username: string, password: string) => {
  const user = users.find((u) => u.username == username);

  if (!user) {
    return null;
  }

  const valid = await bcrypt.compare(password, user.password);

  if (!valid) return null;

  const token = jwt.sign(
    {
      id: user.id,
      role: user.role,
    },
    SECRET,
    { expiresIn: "1h" },
  );
  return token;
};
