import passport from "passport";
import { Strategy, ExtractJwt } from "passport-jwt";

const SECRET = "secret123";

passport.use(
  new Strategy(
    {
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      secretOrKey: SECRET,
    },
    async (payload: any, done: any) => {
      return done(null, payload);
    },
  ),
);

export default passport;
