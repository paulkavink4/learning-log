import express from "express"
import passport  from "./config/passport"
import authRoutes from "./routes/auth.routes"
import documentRoutes from "./routes/document.routes"

const app = express()

app.use(express.json()) // to accept  json as input
app.use(passport.initialize())

app.use("/auth",authRoutes) /// means url containing auth+"" goes to auth route
app.use("/documents",documentRoutes)

app.listen(5000,()=>{
    console.log("Server is Running..");
    
})