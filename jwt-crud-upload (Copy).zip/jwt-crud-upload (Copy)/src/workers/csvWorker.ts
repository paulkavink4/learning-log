import { workerData, parentPort } from "worker_threads";
import fs from "fs";
import { parse } from "csv-parse";

const filePath: string = workerData.filePath;

const results: any[] = [];

fs.createReadStream(filePath)
  .pipe(
    parse({
      columns: true,      // first row becomes object keys
      skip_empty_lines: true,
      trim: true,
    })
  )
  .on("data", (row) => {
    results.push(row);
  })
  .on("end", () => {
    parentPort?.postMessage({ success: true, rows: results });

    // clean up the temp file multer saved
    fs.unlinkSync(filePath);
  })
  .on("error", (err) => {
    parentPort?.postMessage({ success: false, error: err.message });
  });