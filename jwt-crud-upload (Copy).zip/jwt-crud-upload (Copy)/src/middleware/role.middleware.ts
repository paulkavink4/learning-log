import type { Request, Response, NextFunction } from "express";
//Here, double arrow indicate its like function returns another  function
export const authorize=(...roles:string[])=>
(req:any, res:any, next:any)=>{
    if(!roles.includes((req as any).user.role)){
        return res.status(403).json({
            message:"Forbidden"
        })
    }
    next();
}