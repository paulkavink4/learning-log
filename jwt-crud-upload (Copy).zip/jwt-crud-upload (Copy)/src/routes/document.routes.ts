import express from "express"
import {Request, Response} from "express"
import {createDocument,deleteDocument,getDocuments,updateDocument} from "../controllers/document.controller"
import passport from "passport"
import { authorize } from "../middleware/role.middleware";
const router= express.Router()

//Getting all 
router.get(
  "/",
  passport.authenticate("jwt", { session: false }),
  authorize("admin", "employee", "manager"),
  getDocuments
);

//Create
router.post(
  "/create",
  passport.authenticate("jwt", { session: false }),
  authorize("admin", "manager"),
  createDocument
);

//Update
router.put(
  "/:id",
  passport.authenticate("jwt", { session: false }),
  authorize("admin"),
  updateDocument
);

//Delete
router.delete(
  "/:id",
  passport.authenticate("jwt", { session: false }),
  authorize("admin"),
  deleteDocument
);

export default router
