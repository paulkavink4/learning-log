import express from "express"
import { login, register,upload,uploadCsv } from "../controllers/auth.controller"
const router= express.Router()

router.post("/register",register)
router.post("/login",login)
router.post("/upload",upload.single("file"), uploadCsv)

export default router